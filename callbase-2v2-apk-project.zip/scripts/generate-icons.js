import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

function createPNG(width, height, drawFn) {
  // RGBA buffer
  const rawData = Buffer.alloc(height * (1 + width * 4));
  for (let y = 0; y < height; y++) {
    const rowOffset = y * (1 + width * 4);
    rawData[rowOffset] = 0; // Filter type: None
    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const [r, g, b, a] = drawFn(x, y, width, height);
      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  // Deflate IDAT data
  const compressed = zlib.deflateSync(rawData);

  // CRC32 implementation
  const crcTable = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    crcTable[n] = c;
  }

  function crc32(buf, offset, len) {
    let c = 0xffffffff;
    for (let i = 0; i < len; i++) {
      c = crcTable[(c ^ buf[offset + i]) & 0xff] ^ (c >>> 8);
    }
    return (c ^ 0xffffffff) >>> 0;
  }

  function makeChunk(type, data) {
    const len = data.length;
    const chunk = Buffer.alloc(12 + len);
    chunk.writeUInt32BE(len, 0);
    chunk.write(type, 4, 4, 'ascii');
    data.copy(chunk, 8);
    const crc = crc32(chunk, 4, 4 + len);
    chunk.writeUInt32BE(crc, 8 + len);
    return chunk;
  }

  // PNG Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // bit depth
  ihdrData[9] = 6; // color type RGBA
  ihdrData[10] = 0; // compression
  ihdrData[11] = 0; // filter
  ihdrData[12] = 0; // interlace
  const ihdr = makeChunk('IHDR', ihdrData);

  // IDAT chunk
  const idat = makeChunk('IDAT', compressed);

  // IEND chunk
  const iend = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdr, idat, iend]);
}

// Icon design: Deep emerald / casino green gradient, golden spade card motif, 4 suits accent, bold typography
function drawIcon(x, y, w, h, isMaskable = false) {
  const nx = x / w;
  const ny = y / h;
  const cx = 0.5;
  const cy = 0.5;
  const dist = Math.sqrt((nx - cx) ** 2 + (ny - cy) ** 2);

  // Card green gradient background
  let r = Math.round(15 + 20 * (1 - ny));
  let g = Math.round(55 + 40 * (1 - ny));
  let b = Math.round(35 + 25 * (1 - ny));
  let a = 255;

  // Outer border / rounded rect styling for non-maskable
  if (!isMaskable) {
    const cornerRadius = 0.22;
    const dx = Math.max(0, Math.abs(nx - 0.5) - (0.5 - cornerRadius));
    const dy = Math.max(0, Math.abs(ny - 0.5) - (0.5 - cornerRadius));
    const cornerDist = Math.sqrt(dx * dx + dy * dy);
    if (cornerDist > cornerRadius) {
      return [0, 0, 0, 0];
    }
  }

  // Golden inner ring
  const ringDist = Math.abs(dist - 0.38);
  if (ringDist < 0.015) {
    return [245, 190, 60, 255];
  }

  // Central Spade / Card silhouette
  // Center is (0.5, 0.48)
  const sx = (nx - 0.5) * 3.5;
  const sy = (ny - 0.47) * 3.5;

  // Spade formula: heart shape inverted with stem
  // Heart: (x^2 + y^2 - 1)^3 - x^2 * y^3 <= 0
  const spadeY = -sy + 0.15;
  const hx = sx;
  const hy = spadeY;
  const heartEq = Math.pow(hx * hx + hy * hy - 0.45, 3) - hx * hx * Math.pow(hy, 3);

  // Stem
  const isStem = Math.abs(sx) < (sy * 0.45) && sy > 0.1 && sy < 0.65;

  if (heartEq <= 0 || isStem) {
    // Gold gradient with shine
    const goldGlow = 0.8 + 0.2 * Math.sin((nx + ny) * 10);
    return [
      Math.min(255, Math.round(250 * goldGlow)),
      Math.min(255, Math.round(200 * goldGlow)),
      Math.min(255, Math.round(70 * goldGlow)),
      255
    ];
  }

  // Subtle 4 dots in corners representing 4 players
  const playerDots = [
    [0.25, 0.25],
    [0.75, 0.25],
    [0.25, 0.75],
    [0.75, 0.75]
  ];
  for (const [px, py] of playerDots) {
    const pdist = Math.sqrt((nx - px) ** 2 + (ny - py) ** 2);
    if (pdist < 0.04) {
      return [234, 179, 8, 240];
    }
  }

  return [r, g, b, a];
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Write 192x192
const png192 = createPNG(192, 192, (x, y, w, h) => drawIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), png192);

// Write 512x512
const png512 = createPNG(512, 512, (x, y, w, h) => drawIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), png512);

// Write Maskable 512x512
const pngMaskable = createPNG(512, 512, (x, y, w, h) => drawIcon(x, y, w, h, true));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), pngMaskable);

// Write Apple Touch Icon (180x180)
const pngApple = createPNG(180, 180, (x, y, w, h) => drawIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), pngApple);

// Write crisp vector SVG for desktop browsers
const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="100%" height="100%">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#064e3b" />
      <stop offset="50%" stop-color="#043a2c" />
      <stop offset="100%" stop-color="#022c22" />
    </linearGradient>
    <linearGradient id="gold" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fde047" />
      <stop offset="50%" stop-color="#eab308" />
      <stop offset="100%" stop-color="#ca8a04" />
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="8" stdDeviation="12" flood-color="#000" flood-opacity="0.45" />
    </filter>
  </defs>
  <rect width="512" height="512" rx="112" fill="url(#bg)" />
  <circle cx="256" cy="256" r="210" fill="none" stroke="url(#gold)" stroke-width="6" opacity="0.4" stroke-dasharray="10 8" />
  <circle cx="256" cy="256" r="185" fill="none" stroke="url(#gold)" stroke-width="3" opacity="0.7" />
  
  <!-- Central Spade & Card Badges -->
  <g filter="url(#shadow)">
    <!-- Central Spade Icon -->
    <path d="M256,120 C220,170 170,225 170,270 C170,305 198,332 233,332 C248,332 254,324 256,316 C258,324 264,332 279,332 C314,332 342,305 342,270 C342,225 292,170 256,120 Z" fill="url(#gold)" />
    <!-- Spade base -->
    <path d="M245,310 L235,370 L277,370 L267,310 Z" fill="url(#gold)" />
  </g>
  
  <!-- Suit marks around -->
  <text x="90" y="110" font-family="system-ui, sans-serif" font-size="44" font-weight="bold" fill="#ef4444" text-anchor="middle">♥</text>
  <text x="422" y="110" font-family="system-ui, sans-serif" font-size="44" font-weight="bold" fill="#eab308" text-anchor="middle">♠</text>
  <text x="90" y="440" font-family="system-ui, sans-serif" font-size="44" font-weight="bold" fill="#eab308" text-anchor="middle">♣</text>
  <text x="422" y="440" font-family="system-ui, sans-serif" font-size="44" font-weight="bold" fill="#ef4444" text-anchor="middle">♦</text>
  
  <!-- Text Label -->
  <text x="256" y="420" font-family="system-ui, sans-serif" font-size="34" font-weight="900" letter-spacing="4" fill="#ffffff" text-anchor="middle">CALLBASE</text>
  <text x="256" y="452" font-family="system-ui, sans-serif" font-size="20" font-weight="600" fill="#fbbf24" text-anchor="middle">2 VS 2 SCORE COUNTER</text>
</svg>`;
fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgContent);

console.log('Icons generated successfully in public/');
