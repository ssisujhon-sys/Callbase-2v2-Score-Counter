/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { History, Trash2, X, ChevronDown, ChevronUp, Trophy, Calendar, Share2, Check } from 'lucide-react';
import { FinishedGame, Language } from '../types';
import { formatNumber, translations } from '../i18n';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: FinishedGame[];
  lang: Language;
  useBengaliDigits: boolean;
  onDeleteMatch: (id: string) => void;
  onClearAll: () => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  onClose,
  history,
  lang,
  useBengaliDigits,
  onDeleteMatch,
  onClearAll,
}) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const t = translations[lang];

  if (!isOpen) return null;

  const toggleExpand = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  const handleShareMatch = async (g: FinishedGame, e: React.MouseEvent) => {
    e.stopPropagation();
    const winnerName =
      g.winnerTeam === 1 ? g.team1Name : g.winnerTeam === 2 ? g.team2Name : t.tied;

    const text = `🃏 Callbase 2v2 History (${g.date})\n🏆 Winner: ${winnerName}\n🔴 ${g.team1Name}: ${g.finalScore.team1} pts\n🔵 ${g.team2Name}: ${g.finalScore.team2} pts\n📊 Rounds: ${g.totalRounds}\nRecorded with Callbase 2v2 App`;

    if (navigator.share) {
      try {
        await navigator.share({ title: 'Callbase Match Record', text });
        return;
      } catch {
        // fallback
      }
    }

    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(g.id);
      setTimeout(() => setCopiedId(null), 2500);
    } catch {
      // ignore
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-emerald-950 border border-emerald-700/80 w-full max-w-xl max-h-[85vh] rounded-2xl shadow-2xl flex flex-col text-white overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 sm:px-6 border-b border-emerald-800/80 flex items-center justify-between bg-emerald-900/60">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">
                {t.history}
              </h2>
              <p className="text-[11px] text-emerald-300/80">
                {t.offlineModeActive}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <button
                onClick={() => {
                  if (window.confirm(t.clearHistoryConfirm)) {
                    onClearAll();
                  }
                }}
                className="p-1.5 text-xs text-rose-300 hover:text-white bg-rose-950/70 hover:bg-rose-900 border border-rose-800/60 rounded-lg transition cursor-pointer"
                title={t.clearHistory}
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-emerald-900 hover:bg-emerald-800 text-emerald-300"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body / History List */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-3 flex-1">
          {history.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <div className="w-16 h-16 mx-auto rounded-full bg-emerald-900/40 border border-emerald-800 flex items-center justify-center text-emerald-400">
                <History className="w-8 h-8 opacity-40" />
              </div>
              <div className="space-y-1">
                <p className="font-bold text-emerald-200 text-sm">
                  {t.noHistory}
                </p>
                <p className="text-xs text-emerald-400/80 max-w-sm mx-auto">
                  {t.noHistoryDesc}
                </p>
              </div>
            </div>
          ) : (
            history.map((g) => {
              const isExpanded = expandedId === g.id;
              const isT1Winner = g.winnerTeam === 1;
              const isT2Winner = g.winnerTeam === 2;

              return (
                <div
                  key={g.id}
                  className="bg-emerald-900/40 hover:bg-emerald-900/70 border border-emerald-800/70 rounded-xl overflow-hidden transition"
                >
                  {/* Summary Bar */}
                  <div
                    onClick={() => toggleExpand(g.id)}
                    className="p-3.5 flex items-center justify-between gap-3 cursor-pointer select-none"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-emerald-300/80 flex items-center gap-1 font-mono">
                          <Calendar className="w-3 h-3 text-amber-400" />
                          {g.date}
                        </span>
                        <span className="text-[10px] bg-emerald-800/80 px-1.5 py-0.5 rounded text-amber-300 font-bold">
                          {formatNumber(g.totalRounds, lang, useBengaliDigits)} {t.round}
                        </span>
                      </div>

                      {/* Teams & Scores */}
                      <div className="flex items-center gap-3 text-sm font-bold">
                        <span className={`flex items-center gap-1 ${isT1Winner ? 'text-amber-300' : 'text-rose-200'}`}>
                          {isT1Winner && <Trophy className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                          <span className="truncate max-w-[120px]">{g.team1Name}</span>
                          <span className="font-mono text-white">
                            ({formatNumber(g.finalScore.team1, lang, useBengaliDigits)})
                          </span>
                        </span>

                        <span className="text-emerald-500 text-xs">vs</span>

                        <span className={`flex items-center gap-1 ${isT2Winner ? 'text-amber-300' : 'text-blue-200'}`}>
                          {isT2Winner && <Trophy className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                          <span className="truncate max-w-[120px]">{g.team2Name}</span>
                          <span className="font-mono text-white">
                            ({formatNumber(g.finalScore.team2, lang, useBengaliDigits)})
                          </span>
                        </span>
                      </div>
                    </div>

                    {/* Actions on item */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => handleShareMatch(g, e)}
                        className="p-1.5 rounded-lg bg-emerald-800/60 hover:bg-emerald-700 text-emerald-200"
                        title={t.shareMatch}
                      >
                        {copiedId === g.id ? (
                          <Check className="w-3.5 h-3.5 text-amber-400" />
                        ) : (
                          <Share2 className="w-3.5 h-3.5" />
                        )}
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (window.confirm(lang === 'bn' ? 'এই খেলাটি তালিকা থেকে মুছে ফেলতে চান?' : 'Delete this match from history?')) {
                            onDeleteMatch(g.id);
                          }
                        }}
                        className="p-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900 text-rose-300"
                        title={t.deleteMatch}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>

                      <div className="text-emerald-400">
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Expanded breakdown */}
                  {isExpanded && (
                    <div className="p-3.5 bg-emerald-950/80 border-t border-emerald-800/60 text-xs space-y-3">
                      {/* Player Lineup */}
                      <div className="grid grid-cols-2 gap-2 text-[11px] bg-emerald-900/30 p-2 rounded-lg border border-emerald-800/40">
                        <div>
                          <strong className="text-rose-300 block">{g.team1Name}:</strong>
                          <span className="text-emerald-200/90">
                            {g.playerNames.p1} & {g.playerNames.p3}
                          </span>
                        </div>
                        <div>
                          <strong className="text-blue-300 block">{g.team2Name}:</strong>
                          <span className="text-emerald-200/90">
                            {g.playerNames.p2} & {g.playerNames.p4}
                          </span>
                        </div>
                      </div>

                      {/* Round-by-round mini table */}
                      <div className="space-y-1">
                        <div className="font-bold text-amber-300 text-[11px] uppercase tracking-wider">
                          {t.roundDetails}
                        </div>
                        <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
                          {g.rounds.map((r) => (
                            <div
                              key={r.roundNumber}
                              className="flex items-center justify-between p-2 rounded bg-emerald-900/50 border border-emerald-800/40 text-[11px]"
                            >
                              <span className="font-mono font-bold text-amber-300">
                                R{formatNumber(r.roundNumber, lang, useBengaliDigits)}
                              </span>

                              {/* Team 1 round stat */}
                              <span className="font-mono text-rose-200">
                                <span>{g.team1Name.slice(0, 6)}: </span>
                                +{formatNumber(r.team1Call, lang, useBengaliDigits)} ({formatNumber(r.team1TotalScore, lang, useBengaliDigits)})
                              </span>

                              {/* Team 2 round stat */}
                              <span className="font-mono text-blue-200">
                                <span>{g.team2Name.slice(0, 6)}: </span>
                                +{formatNumber(r.team2Call, lang, useBengaliDigits)} ({formatNumber(r.team2TotalScore, lang, useBengaliDigits)})
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
