/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BookOpen, X, CheckCircle } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../i18n';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose, lang }) => {
  const t = translations[lang];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-emerald-950 border border-emerald-700/80 w-full max-w-lg rounded-2xl shadow-2xl p-5 sm:p-6 text-white space-y-4 relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">
              {t.rulesTitle}
            </h2>
            <p className="text-xs text-emerald-300/80">
              {lang === 'bn' ? '২ বনাম ২ দলের মোট স্কোর গণনা ও নিয়ম' : '2 vs 2 Team Call & Score Counter Guide'}
            </p>
          </div>
        </div>

        <div className="text-xs space-y-3.5 text-emerald-100/90 leading-relaxed">
          {/* Partnership */}
          <div className="bg-emerald-900/40 p-3 rounded-xl border border-emerald-800/60 space-y-1">
            <div className="font-bold text-amber-300 text-sm">
              {lang === 'bn' ? '১. ৪ জন খেলোয়াড় এবং ২ বনাম ২ টিম' : '1. 4 Players & 2 vs 2 Team Setup'}
            </div>
            <p>
              {lang === 'bn'
                ? 'খেলোয়াড় ১ ও খেলোয়াড় ৩ হলো দল ১। মুখোমুখি বসা খেলোয়াড় ২ ও খেলোয়াড় ৪ হলো দল ২। দুই পার্টনারের মিলিত ডাক দিয়ে দলের প্রতি রাউন্ডের স্কোর নির্ধারিত হয়।'
                : 'Player 1 and Player 3 form Team 1. Player 2 and Player 4 form Team 2. Partners sit opposite each other and combine their individual calls to form the Team Round Score.'}
            </p>
          </div>

          {/* Bidding */}
          <div className="bg-emerald-900/40 p-3 rounded-xl border border-emerald-800/60 space-y-1">
            <div className="font-bold text-amber-300 text-sm">
              {lang === 'bn' ? '২. কল বা ডাক (৫০, ১০০, ১৫০, ২০০)' : '2. Player Calls (50, 100, 150, 200)'}
            </div>
            <p>
              {lang === 'bn'
                ? 'প্রতিটি খেলোয়াড়ের জন্য ৫০, ১০০, ১৫০ বা ২০০ বাটনে চাপুন অথবা পাস (০) দিন। কোনো ভুল হলে সাথে থাকা Undo বা Reset বাটনে চাপ দিয়ে ঠিক করা যায়।'
                : 'Tap 50, 100, 150, or 200 for each player, or Pass (0). If a mistake is made, use the Undo/Reset button on that player card to correct it.'}
            </p>
          </div>

          {/* Direct team score counting */}
          <div className="bg-emerald-900/40 p-3 rounded-xl border border-emerald-800/60 space-y-1">
            <div className="font-bold text-amber-300 text-sm">
              {lang === 'bn' ? '৩. প্রতিটি দলের মোট স্কোর গণনা' : '3. Counting Each Team Total Score'}
            </div>
            <div className="space-y-1.5">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  {lang === 'bn'
                    ? 'প্রতি রাউন্ডে দল ১ এর মোট কল (P1 + P3) এবং দল ২ এর মোট কল (P2 + P4) সরাসরি তাদের মোট স্কোরে যোগ হয়ে যায়।'
                    : 'In each round, Team 1 calls (P1 + P3) and Team 2 calls (P2 + P4) are directly counted into each team cumulative total score.'}
                </span>
              </div>
            </div>
          </div>

          {/* Edit & Undo */}
          <div className="bg-emerald-900/40 p-3 rounded-xl border border-emerald-800/60 space-y-1">
            <div className="font-bold text-amber-300 text-sm">
              {lang === 'bn' ? '৪. যেকোনো কলের এডিট ও আনডু সুবিধা' : '4. Edit & Undo Capability'}
            </div>
            <p>
              {lang === 'bn'
                ? 'রাউন্ড তালিকার যেকোনো রাউন্ডের ডানপাশের Edit বাটনে চাপলে পূর্বের যেকোনো কল পরিবর্তন করা যাবে এবং পুরো স্কোর স্বয়ংক্রিয়ভাবে নতুন করে হিসাব হবে। শেষ রাউন্ডটি Undo বাটনে মুছে দেওয়া যায়।'
                : 'Tap the Edit button on any previous round in the history table to modify any player call. Total scores will automatically recalculate. The last round can also be undone.'}
            </p>
          </div>

          {/* Finish & History */}
          <div className="bg-emerald-900/40 p-3 rounded-xl border border-emerald-800/60 space-y-1">
            <div className="font-bold text-amber-300 text-sm">
              {lang === 'bn' ? '৫. খেলা সমাপ্ত ও ফোনের মেমরিতে সেভ' : '5. Finish Game & Offline Saved History'}
            </div>
            <p>
              {lang === 'bn'
                ? '"খেলা সমাপ্ত করুন" বাটনে চাপলেই বিজয়ী নির্ধারণ হবে এবং সম্পূর্ণ খেলার তথ্য মোবাইলের মেমরিতে সেভ থাকবে।'
                : 'Click "Finish Game" whenever you wish to conclude. The winner will be crowned and the full match scorecard will be permanently saved to your mobile local storage.'}
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs cursor-pointer"
        >
          {t.cancel}
        </button>
      </div>
    </div>
  );
};
