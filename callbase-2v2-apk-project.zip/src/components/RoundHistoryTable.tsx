/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Undo2, ChevronDown, ChevronUp, History, Edit3, Trash2 } from 'lucide-react';
import { GameSettings, Language, Round } from '../types';
import { formatNumber, translations } from '../i18n';

interface RoundHistoryTableProps {
  rounds: Round[];
  settings: GameSettings;
  lang: Language;
  onDeleteLastRound: () => void;
  onDeleteSpecificRound: (roundNumber: number) => void;
  onOpenEditRound: (round: Round) => void;
}

export const RoundHistoryTable: React.FC<RoundHistoryTableProps> = ({
  rounds,
  settings,
  lang,
  onDeleteLastRound,
  onDeleteSpecificRound,
  onOpenEditRound,
}) => {
  const t = translations[lang];
  const { team1Name, team2Name, playerNames, useBengaliDigits } = settings;

  // Collapsible history accordion (default open if rounds exist, can collapse to save screen)
  const [isOpen, setIsOpen] = useState<boolean>(true);
  const [expandedRound, setExpandedRound] = useState<number | null>(null);

  if (rounds.length === 0) {
    return null;
  }

  const toggleExpand = (roundNum: number) => {
    setExpandedRound((prev) => (prev === roundNum ? null : roundNum));
  };

  return (
    <div className="bg-emerald-950/80 border border-emerald-800/70 rounded-xl p-3 shadow-md space-y-2">
      {/* Header bar with toggle */}
      <div className="flex items-center justify-between pb-1.5 border-b border-emerald-800/60 text-xs">
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-1.5 text-white font-bold hover:text-amber-300 transition cursor-pointer"
        >
          <History className="w-3.5 h-3.5 text-amber-400" />
          <span>
            {t.roundDetails} ({formatNumber(rounds.length, lang, useBengaliDigits)})
          </span>
          {isOpen ? (
            <ChevronUp className="w-3.5 h-3.5 text-emerald-400" />
          ) : (
            <ChevronDown className="w-3.5 h-3.5 text-emerald-400" />
          )}
        </button>

        <button
          onClick={onDeleteLastRound}
          className="text-[11px] text-rose-300 hover:text-white bg-rose-950/60 hover:bg-rose-900/80 px-2 py-0.5 rounded border border-rose-800/60 flex items-center gap-1 transition cursor-pointer"
          title={t.undoLastRound}
        >
          <Undo2 className="w-3 h-3" />
          <span>{t.undoLastRound}</span>
        </button>
      </div>

      {/* Collapsible list */}
      {isOpen && (
        <div className="space-y-1.5 max-h-56 overflow-y-auto pr-0.5">
          {rounds
            .slice()
            .reverse()
            .map((r) => {
              const isExpanded = expandedRound === r.roundNumber;

              return (
                <div
                  key={r.roundNumber}
                  className="bg-emerald-900/40 hover:bg-emerald-900/60 border border-emerald-800/60 rounded-lg transition overflow-hidden text-xs"
                >
                  {/* Summary Row */}
                  <div
                    onClick={() => toggleExpand(r.roundNumber)}
                    className="p-2 flex items-center justify-between gap-1.5 cursor-pointer select-none"
                  >
                    <div className="flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded bg-emerald-800 text-amber-300 font-bold font-mono text-[10px] flex items-center justify-center shrink-0">
                        R{formatNumber(r.roundNumber, lang, useBengaliDigits)}
                      </span>
                    </div>

                    {/* Team 1 & Team 2 scores */}
                    <div className="flex items-center gap-2 sm:gap-4 text-[11px]">
                      {/* Team 1 */}
                      <div className="flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                        <span className="text-rose-200 font-bold font-mono">
                          +{formatNumber(r.team1Call, lang, useBengaliDigits)}
                        </span>
                        <span className="text-[10px] text-emerald-400 font-mono">
                          ({formatNumber(r.team1TotalScore, lang, useBengaliDigits)})
                        </span>
                      </div>

                      <span className="text-emerald-700">|</span>

                      {/* Team 2 */}
                      <div className="flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                        <span className="text-blue-200 font-bold font-mono">
                          +{formatNumber(r.team2Call, lang, useBengaliDigits)}
                        </span>
                        <span className="text-[10px] text-emerald-400 font-mono">
                          ({formatNumber(r.team2TotalScore, lang, useBengaliDigits)})
                        </span>
                      </div>
                    </div>

                    {/* Actions: Edit & Delete */}
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenEditRound(r);
                        }}
                        className="p-1 rounded bg-emerald-800/80 hover:bg-amber-500 hover:text-emerald-950 text-emerald-200 border border-emerald-700/60 transition"
                        title={t.editCall}
                      >
                        <Edit3 className="w-3 h-3" />
                      </button>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteSpecificRound(r.roundNumber);
                        }}
                        className="p-1 rounded bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800/50 transition"
                        title="Delete this round"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>

                      <div className="text-emerald-400 ml-0.5">
                        {isExpanded ? (
                          <ChevronUp className="w-3 h-3" />
                        ) : (
                          <ChevronDown className="w-3 h-3" />
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Expanded breakdown */}
                  {isExpanded && (
                    <div className="px-2.5 pb-2 pt-1 border-t border-emerald-800/40 bg-emerald-950/70 text-[11px] space-y-1">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="bg-rose-950/20 p-1.5 rounded border border-rose-900/30">
                          <div className="font-bold text-rose-300 text-[10px] pb-0.5 mb-0.5 border-b border-rose-900/40">
                            {team1Name} (Total: {formatNumber(r.team1TotalScore, lang, useBengaliDigits)})
                          </div>
                          <div className="flex justify-between text-emerald-300">
                            <span>{playerNames.p1}:</span>
                            <span className="font-mono text-amber-300">{formatNumber(r.calls.p1, lang, useBengaliDigits)}</span>
                          </div>
                          <div className="flex justify-between text-emerald-300">
                            <span>{playerNames.p3}:</span>
                            <span className="font-mono text-amber-300">{formatNumber(r.calls.p3, lang, useBengaliDigits)}</span>
                          </div>
                        </div>

                        <div className="bg-blue-950/20 p-1.5 rounded border border-blue-900/30">
                          <div className="font-bold text-blue-300 text-[10px] pb-0.5 mb-0.5 border-b border-blue-900/40">
                            {team2Name} (Total: {formatNumber(r.team2TotalScore, lang, useBengaliDigits)})
                          </div>
                          <div className="flex justify-between text-emerald-300">
                            <span>{playerNames.p2}:</span>
                            <span className="font-mono text-amber-300">{formatNumber(r.calls.p2, lang, useBengaliDigits)}</span>
                          </div>
                          <div className="flex justify-between text-emerald-300">
                            <span>{playerNames.p4}:</span>
                            <span className="font-mono text-amber-300">{formatNumber(r.calls.p4, lang, useBengaliDigits)}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
        </div>
      )}
    </div>
  );
};
