/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Smartphone, Download, CheckCircle2, ShieldCheck, WifiOff, X, ExternalLink } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../i18n';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  const t = translations[lang];
  const { isInstallable, install, isInstalled } = usePWAInstall();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-emerald-950 border border-emerald-700/80 w-full max-w-lg rounded-2xl shadow-2xl p-5 sm:p-6 text-white space-y-5 relative max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-emerald-950 shadow-md">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">
              {t.installAndroidTitle}
            </h2>
            <p className="text-xs text-emerald-300/80">
              {t.installGuide}
            </p>
          </div>
        </div>

        {/* App status highlight */}
        <div className="bg-emerald-900/40 border border-emerald-700/60 rounded-xl p-4 space-y-3">
          <div className="flex items-start gap-2.5">
            <WifiOff className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs space-y-0.5">
              <strong className="text-amber-300 text-sm block">
                {t.offlineReady}
              </strong>
              <p className="text-emerald-200/90 leading-relaxed">
                {t.installAndroidDesc}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 pt-2 border-t border-emerald-800/80 text-xs text-emerald-300">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              {lang === 'bn' ? 'কোনো ইন্টারনেট লাগবে না' : 'No Internet Required'}
            </span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              {lang === 'bn' ? 'ফোনে ডাটা নিরাপদ' : '100% On-Device Storage'}
            </span>
          </div>
        </div>

        {/* 1-Tap Direct Install (if browser supports prompt) */}
        {isInstallable && !isInstalled && (
          <div className="text-center space-y-2">
            <button
              onClick={async () => {
                const res = await install();
                if (res) onClose();
              }}
              className="w-full py-3.5 px-4 rounded-xl font-black text-sm bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-emerald-950 shadow-lg flex items-center justify-center gap-2 transition active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>{t.installBtn}</span>
            </button>
            <p className="text-[11px] text-emerald-400/80">
              {lang === 'bn' ? '১ ক্লিকেই ফোনের অ্যাপ ড্রয়ারে যুক্ত হবে' : 'Instantly installs to your home screen launcher'}
            </p>
          </div>
        )}

        {/* Manual Step-by-Step for Android Chrome */}
        <div className="space-y-2 bg-emerald-900/30 p-3.5 rounded-xl border border-emerald-800/60">
          <div className="font-bold text-xs text-amber-300 uppercase tracking-wider">
            {lang === 'bn' ? 'অ্যান্ড্রয়েড ফোনে যেভাবে অ্যাপ হিসেবে চালু করবেন:' : 'How to install on Android Chrome:'}
          </div>
          <ol className="text-xs text-emerald-100/90 space-y-2 list-decimal list-inside leading-relaxed">
            <li>
              {lang === 'bn'
                ? 'ফোনের Google Chrome ব্রাউজারে উপরে ডানে ৩-ডট (⋮) মেনুতে চাপুন।'
                : 'Tap the 3 dots (⋮) menu at the top right in Google Chrome.'}
            </li>
            <li>
              {lang === 'bn'
                ? 'মেনু থেকে "Install app" অথবা "Add to Home screen" সিলেক্ট করুন।'
                : 'Select "Install app" or "Add to Home screen".'}
            </li>
            <li>
              {lang === 'bn'
                ? 'ইনস্টল কনফার্ম করলেই এটি মোবাইলের আসল APK অ্যাপের মতো ফুলস্ক্রিনে চলবে।'
                : 'Confirm install. The app will launch in standalone fullscreen mode without browser URL bars.'}
            </li>
          </ol>
        </div>

        {/* Standalone APK information */}
        <div className="bg-emerald-900/20 p-3 rounded-xl border border-emerald-800/40 text-[11px] text-emerald-300/80 space-y-1.5">
          <div className="font-bold text-emerald-200 flex items-center gap-1">
            <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'bn' ? 'সরাসরি .apk ফাইল বানাতে চান?' : 'Need a standalone .apk package?'}</span>
          </div>
          <p className="leading-relaxed">
            {t.apkNotice}
          </p>
        </div>

        {/* Action Button */}
        <div>
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs transition"
          >
            {t.cancel}
          </button>
        </div>
      </div>
    </div>
  );
};
