/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Flag } from 'lucide-react';
import { GameSettings, Language } from '../types';
import { formatNumber, translations } from '../i18n';

interface ScoreBoardProps {
  team1Score: number;
  team2Score: number;
  settings: GameSettings;
  currentRoundNumber: number;
  currentDealer: 'p1' | 'p2' | 'p3' | 'p4';
  lang: Language;
  onFinishGame: () => void;
}

export const ScoreBoard: React.FC<ScoreBoardProps> = ({
  team1Score,
  team2Score,
  settings,
  currentRoundNumber,
  currentDealer,
  lang,
  onFinishGame,
}) => {
  const t = translations[lang];
  const { team1Name, team2Name, playerNames, useBengaliDigits } = settings;

  return (
    <div className="bg-emerald-950/95 border border-emerald-700/70 rounded-xl px-3 py-2 shadow-lg shadow-black/30">
      <div className="flex items-center justify-between gap-2">
        {/* Team 1 Score (Compact Pill) */}
        <div className="flex items-center gap-2 bg-rose-950/40 border border-rose-800/60 rounded-lg px-2.5 py-1.5 min-w-0 flex-1">
          <div className="w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0" />
          <div className="min-w-0">
            <div className="text-[10px] text-rose-300 font-semibold truncate leading-tight">
              {team1Name}
            </div>
            <div className="text-xl sm:text-2xl font-black font-mono text-white leading-tight">
              {formatNumber(team1Score, lang, useBengaliDigits)}
              <span className="text-[10px] text-rose-300/80 font-normal ml-0.5">pts</span>
            </div>
          </div>
        </div>

        {/* Center Round & Dealer info */}
        <div className="flex flex-col items-center justify-center shrink-0 px-1">
          <span className="px-2 py-0.5 rounded bg-emerald-800 text-amber-300 font-bold font-mono text-xs border border-emerald-700 shadow-inner">
            {t.round} {formatNumber(currentRoundNumber, lang, useBengaliDigits)}
          </span>
          <span className="text-[10px] text-emerald-300/90 mt-0.5 font-medium">
            {t.dealer}: <strong className="text-amber-300">{playerNames[currentDealer]}</strong>
          </span>
        </div>

        {/* Team 2 Score (Compact Pill) */}
        <div className="flex items-center justify-between gap-2 bg-blue-950/40 border border-blue-800/60 rounded-lg px-2.5 py-1.5 min-w-0 flex-1">
          <div className="min-w-0">
            <div className="text-[10px] text-blue-300 font-semibold truncate leading-tight">
              {team2Name}
            </div>
            <div className="text-xl sm:text-2xl font-black font-mono text-white leading-tight">
              {formatNumber(team2Score, lang, useBengaliDigits)}
              <span className="text-[10px] text-blue-300/80 font-normal ml-0.5">pts</span>
            </div>
          </div>
          <div className="w-2.5 h-2.5 rounded-full bg-blue-500 shrink-0" />
        </div>

        {/* Finish button */}
        <button
          onClick={onFinishGame}
          className="p-2 sm:px-3 sm:py-2 rounded-lg bg-rose-700 hover:bg-rose-600 text-white font-bold text-xs shadow border border-rose-500/50 flex items-center gap-1 shrink-0 cursor-pointer active:scale-95 transition"
          title={t.finishGame}
        >
          <Flag className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">{t.finishGame}</span>
        </button>
      </div>
    </div>
  );
};
