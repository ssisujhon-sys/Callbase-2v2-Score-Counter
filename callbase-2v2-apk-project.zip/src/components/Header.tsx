/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Download, History, RotateCcw, Settings, Volume2, VolumeX, BookOpen, Smartphone } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../i18n';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface HeaderProps {
  lang: Language;
  onToggleLang: () => void;
  onOpenHistory: () => void;
  onOpenSettings: () => void;
  onOpenRules: () => void;
  onOpenInstallGuide: () => void;
  onResetGame: () => void;
  historyCount: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onToggleLang,
  onOpenHistory,
  onOpenSettings,
  onOpenRules,
  onOpenInstallGuide,
  onResetGame,
  historyCount,
  soundEnabled,
  onToggleSound,
}) => {
  const t = translations[lang];
  const { isInstallable, install, isInstalled } = usePWAInstall();

  return (
    <header className="sticky top-0 z-30 bg-emerald-950/90 backdrop-blur-md border-b border-emerald-800/60 shadow-lg px-3 py-2.5 sm:px-6">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
        {/* Brand / Logo */}
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-md shadow-amber-950/40 border border-amber-300/40 text-emerald-950 font-black text-xl shrink-0">
            ♠
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-base sm:text-lg tracking-tight text-white flex items-center gap-1.5">
                {t.appName}
                <span className="text-[11px] font-semibold px-1.5 py-0.5 rounded bg-emerald-800/80 text-amber-300 border border-emerald-700/60 uppercase">
                  2v2
                </span>
              </h1>
            </div>
            <p className="text-[11px] text-emerald-200/80 hidden sm:block">
              {t.appSubtitle}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Direct Install Button (Chrome / Android PWA prompt) */}
          {isInstallable && !isInstalled && (
            <button
              onClick={install}
              className="flex items-center gap-1 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-emerald-950 font-bold px-2.5 py-1.5 rounded-lg text-xs shadow-md shadow-amber-900/30 transition transform active:scale-95 animate-pulse"
              title={t.installApp}
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">{t.installApp}</span>
              <span className="md:hidden">APK</span>
            </button>
          )}

          {/* Android APK / Mobile Install Guide Button */}
          <button
            onClick={onOpenInstallGuide}
            className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg bg-emerald-900/80 hover:bg-emerald-850 border border-emerald-700/60 text-emerald-200 hover:text-white text-xs font-medium transition flex items-center gap-1"
            title={t.installGuide}
          >
            <Smartphone className="w-4 h-4 text-amber-400" />
            <span className="hidden lg:inline">{t.installGuide}</span>
          </button>

          {/* Language Switcher */}
          <button
            onClick={onToggleLang}
            className="px-2 py-1 sm:px-2.5 sm:py-1 rounded-lg bg-emerald-900/80 hover:bg-emerald-800 border border-emerald-700/70 text-amber-300 font-bold text-xs tracking-wider transition active:scale-95"
            title="Toggle English / বাংলা"
          >
            {lang === 'en' ? 'বাংলা' : 'EN'}
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className="p-1.5 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 border border-emerald-700/50 text-emerald-300 transition"
            title={t.soundEffects}
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-300" />
            ) : (
              <VolumeX className="w-4 h-4 text-emerald-500" />
            )}
          </button>

          {/* Rules / Help */}
          <button
            onClick={onOpenRules}
            className="p-1.5 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 border border-emerald-700/50 text-emerald-300 transition"
            title={t.rulesHelp}
          >
            <BookOpen className="w-4 h-4" />
          </button>

          {/* History Button with Counter Badge */}
          <button
            onClick={onOpenHistory}
            className="relative p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg bg-emerald-900/80 hover:bg-emerald-800 border border-emerald-700/60 text-emerald-200 hover:text-white text-xs font-semibold flex items-center gap-1 transition"
            title={t.history}
          >
            <History className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">{t.history}</span>
            {historyCount > 0 && (
              <span className="inline-flex items-center justify-center min-w-4 h-4 px-1 text-[10px] font-black bg-amber-500 text-emerald-950 rounded-full leading-none">
                {historyCount}
              </span>
            )}
          </button>

          {/* New Game / Reset */}
          <button
            onClick={onResetGame}
            className="p-1.5 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 border border-emerald-700/50 text-emerald-300 hover:text-amber-300 transition"
            title={t.resetGame}
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Settings */}
          <button
            onClick={onOpenSettings}
            className="p-1.5 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 border border-emerald-700/50 text-emerald-300 hover:text-white transition"
            title={t.settings}
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
