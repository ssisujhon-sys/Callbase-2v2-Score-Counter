/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Play, Users, Shield, Award, ArrowRight, History, Sparkles, BookOpen } from 'lucide-react';
import { GameSettings, Language } from '../types';
import { translations } from '../i18n';
import { soundEngine } from '../hooks/useSound';

interface StartGameModalProps {
  isOpen: boolean;
  hasActiveGame: boolean;
  activeRoundCount: number;
  settings: GameSettings;
  lang: Language;
  onToggleLang: () => void;
  onResumeGame: () => void;
  onConfirmStartGame: (updatedSettings: GameSettings) => void;
  onOpenHistory: () => void;
  onOpenRules: () => void;
}

export const StartGameModal: React.FC<StartGameModalProps> = ({
  isOpen,
  hasActiveGame,
  activeRoundCount,
  settings,
  lang,
  onToggleLang,
  onResumeGame,
  onConfirmStartGame,
  onOpenHistory,
  onOpenRules,
}) => {
  const t = translations[lang];

  // Mode: 'welcome' | 'names'
  const [step, setStep] = useState<'welcome' | 'names'>('welcome');

  // Form state for names
  const [team1Name, setTeam1Name] = useState(settings.team1Name);
  const [team2Name, setTeam2Name] = useState(settings.team2Name);
  const [playerNames, setPlayerNames] = useState({ ...settings.playerNames });

  if (!isOpen) return null;

  const handleStartGameClick = () => {
    if (settings.soundEnabled) soundEngine.playChip();
    setStep('names');
  };

  const handleConfirmBegin = (e: React.FormEvent) => {
    e.preventDefault();
    if (settings.soundEnabled) soundEngine.playSuccess();
    onConfirmStartGame({
      ...settings,
      team1Name: team1Name.trim() || t.team1Default,
      team2Name: team2Name.trim() || t.team2Default,
      playerNames: {
        p1: playerNames.p1.trim() || t.player1Default,
        p2: playerNames.p2.trim() || t.player2Default,
        p3: playerNames.p3.trim() || t.player3Default,
        p4: playerNames.p4.trim() || t.player4Default,
      },
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-gradient-to-b from-emerald-900 to-emerald-950 border border-emerald-600/60 w-full max-w-md rounded-2xl shadow-2xl p-5 sm:p-6 text-white space-y-5 relative overflow-hidden">
        {/* Subtle decorative glow */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Top bar with Language switch */}
        <div className="flex items-center justify-between pb-2 border-b border-emerald-800/60 text-xs">
          <span className="text-[11px] text-emerald-300 font-semibold tracking-wide">
            ♠ CALLBASE 2V2
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onToggleLang}
              className="px-2.5 py-1 rounded-lg bg-emerald-800/80 hover:bg-emerald-700 text-amber-300 font-bold border border-emerald-600/60 transition"
            >
              {lang === 'en' ? 'বাংলা' : 'EN'}
            </button>
          </div>
        </div>

        {/* Step 1: Welcome & Start Game Button */}
        {step === 'welcome' && (
          <div className="text-center space-y-5 py-2">
            {/* Logo & Suits Icon */}
            <div className="flex justify-center">
              <div className="relative">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 flex items-center justify-center shadow-xl shadow-amber-950/60 border-2 border-amber-300/60 text-emerald-950 font-black text-4xl">
                  ♠
                </div>
                <div className="absolute -bottom-2 -right-2 bg-emerald-800 border border-amber-400 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-full shadow">
                  2 vs 2
                </div>
              </div>
            </div>

            {/* Title & Description */}
            <div className="space-y-1">
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                {t.welcomeTitle}
              </h1>
              <p className="text-xs sm:text-sm text-emerald-200/90 max-w-xs mx-auto">
                {t.welcomeSubtitle}
              </p>
            </div>

            {/* Main Action Buttons */}
            <div className="space-y-3 pt-2">
              {/* START GAME BUTTON */}
              <button
                onClick={handleStartGameClick}
                className="w-full py-4 px-6 rounded-xl font-black text-base bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-emerald-950 shadow-lg shadow-amber-950/50 flex items-center justify-center gap-2 transition transform active:scale-98 cursor-pointer border border-amber-300/80"
              >
                <Play className="w-5 h-5 fill-emerald-950" />
                <span>{t.startGame}</span>
                <ArrowRight className="w-5 h-5 ml-1" />
              </button>

              {/* Resume Match Button (if an active game exists) */}
              {hasActiveGame && (
                <button
                  onClick={onResumeGame}
                  className="w-full py-3 px-4 rounded-xl font-bold text-xs sm:text-sm bg-emerald-800/80 hover:bg-emerald-700 text-emerald-100 border border-emerald-600/70 flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>
                    {t.resumeGame} ({activeRoundCount} {lang === 'bn' ? 'রাউন্ড সম্পন্ন' : 'rounds'})
                  </span>
                </button>
              )}
            </div>

            {/* Bottom utilities: History & Rules */}
            <div className="flex items-center justify-center gap-4 pt-3 border-t border-emerald-800/60 text-xs text-emerald-300">
              <button
                onClick={onOpenHistory}
                className="hover:text-amber-300 flex items-center gap-1.5 transition"
              >
                <History className="w-3.5 h-3.5 text-amber-400" />
                <span>{t.history}</span>
              </button>
              <span className="text-emerald-700">•</span>
              <button
                onClick={onOpenRules}
                className="hover:text-amber-300 flex items-center gap-1.5 transition"
              >
                <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                <span>{t.rulesHelp}</span>
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Player Names Entry */}
        {step === 'names' && (
          <form onSubmit={handleConfirmBegin} className="space-y-4">
            <div className="text-center space-y-0.5">
              <div className="inline-flex p-2 rounded-xl bg-amber-500/20 text-amber-400 mb-1">
                <Users className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold text-white">
                {t.enterPlayerNames}
              </h2>
              <p className="text-[11px] text-emerald-300/80">
                {t.enterPlayerNamesDesc}
              </p>
            </div>

            {/* Team 1 Partners (Player 1 & 3) */}
            <div className="bg-rose-950/30 border border-rose-800/60 rounded-xl p-3 space-y-2.5">
              <div className="flex items-center gap-2 pb-1 border-b border-rose-900/40">
                <Shield className="w-4 h-4 text-rose-400 shrink-0" />
                <input
                  type="text"
                  value={team1Name}
                  onChange={(e) => setTeam1Name(e.target.value)}
                  placeholder={t.team1Default}
                  className="w-full text-xs font-bold bg-emerald-950 text-rose-200 border border-rose-800/60 rounded px-2.5 py-1 focus:outline-none focus:ring-1 focus:ring-rose-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-[10px] text-emerald-300/90 block mb-0.5 font-medium">
                    Player 1 (Team 1)
                  </label>
                  <input
                    type="text"
                    required
                    value={playerNames.p1}
                    onChange={(e) => setPlayerNames({ ...playerNames, p1: e.target.value })}
                    className="w-full bg-emerald-950 text-white font-semibold text-xs border border-emerald-700/80 rounded px-2.5 py-1.5 focus:ring-1 focus:ring-amber-400"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-emerald-300/90 block mb-0.5 font-medium">
                    Player 3 (Team 1 Partner)
                  </label>
                  <input
                    type="text"
                    required
                    value={playerNames.p3}
                    onChange={(e) => setPlayerNames({ ...playerNames, p3: e.target.value })}
                    className="w-full bg-emerald-950 text-white font-semibold text-xs border border-emerald-700/80 rounded px-2.5 py-1.5 focus:ring-1 focus:ring-amber-400"
                  />
                </div>
              </div>
            </div>

            {/* Team 2 Partners (Player 2 & 4) */}
            <div className="bg-blue-950/30 border border-blue-800/60 rounded-xl p-3 space-y-2.5">
              <div className="flex items-center gap-2 pb-1 border-b border-blue-900/40">
                <Award className="w-4 h-4 text-blue-400 shrink-0" />
                <input
                  type="text"
                  value={team2Name}
                  onChange={(e) => setTeam2Name(e.target.value)}
                  placeholder={t.team2Default}
                  className="w-full text-xs font-bold bg-emerald-950 text-blue-200 border border-blue-800/60 rounded px-2.5 py-1 focus:outline-none focus:ring-1 focus:ring-blue-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-[10px] text-emerald-300/90 block mb-0.5 font-medium">
                    Player 2 (Team 2)
                  </label>
                  <input
                    type="text"
                    required
                    value={playerNames.p2}
                    onChange={(e) => setPlayerNames({ ...playerNames, p2: e.target.value })}
                    className="w-full bg-emerald-950 text-white font-semibold text-xs border border-emerald-700/80 rounded px-2.5 py-1.5 focus:ring-1 focus:ring-amber-400"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-emerald-300/90 block mb-0.5 font-medium">
                    Player 4 (Team 2 Partner)
                  </label>
                  <input
                    type="text"
                    required
                    value={playerNames.p4}
                    onChange={(e) => setPlayerNames({ ...playerNames, p4: e.target.value })}
                    className="w-full bg-emerald-950 text-white font-semibold text-xs border border-emerald-700/80 rounded px-2.5 py-1.5 focus:ring-1 focus:ring-amber-400"
                  />
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 pt-2 border-t border-emerald-800/60">
              <button
                type="button"
                onClick={() => setStep('welcome')}
                className="w-1/3 py-3 rounded-xl bg-emerald-900 hover:bg-emerald-850 text-xs text-emerald-200 font-semibold transition"
              >
                {lang === 'bn' ? 'পেছনে যান' : 'Back'}
              </button>

              <button
                type="submit"
                className="w-2/3 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-emerald-950 font-black text-sm shadow-md flex items-center justify-center gap-1.5 transition active:scale-98 cursor-pointer"
              >
                <Play className="w-4 h-4 fill-emerald-950" />
                <span>{t.beginMatch}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
