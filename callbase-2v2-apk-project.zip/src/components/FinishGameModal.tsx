/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Trophy, Share2, RotateCcw, History, Check, X, Shield, Award } from 'lucide-react';
import { GameSettings, Language, Round } from '../types';
import { formatNumber, translations } from '../i18n';

interface FinishGameModalProps {
  isOpen: boolean;
  onClose: () => void;
  team1Score: number;
  team2Score: number;
  rounds: Round[];
  settings: GameSettings;
  lang: Language;
  onSaveAndReset: () => void;
  onOpenHistory: () => void;
}

export const FinishGameModal: React.FC<FinishGameModalProps> = ({
  isOpen,
  onClose,
  team1Score,
  team2Score,
  rounds,
  settings,
  lang,
  onSaveAndReset,
  onOpenHistory,
}) => {
  const [copied, setCopied] = useState(false);
  const t = translations[lang];
  const { team1Name, team2Name, playerNames, useBengaliDigits } = settings;

  if (!isOpen) return null;

  const winner = team1Score > team2Score ? 1 : team2Score > team1Score ? 2 : 'tie';
  const winnerName = winner === 1 ? team1Name : winner === 2 ? team2Name : t.tied;
  const scoreDiff = Math.abs(team1Score - team2Score);

  const handleShare = async () => {
    const text = `🃏 Callbase 2v2 Match Result\n🏆 Winner: ${winnerName}\n🔴 ${team1Name}: ${team1Score} pts (${playerNames.p1} & ${playerNames.p3})\n🔵 ${team2Name}: ${team2Score} pts (${playerNames.p2} & ${playerNames.p4})\n📊 Rounds Played: ${rounds.length}\nRecorded with Callbase 2v2 App`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Callbase 2v2 Match Result',
          text,
        });
        return;
      } catch {
        // fallback to clipboard
      }
    }

    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // ignore
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-gradient-to-b from-emerald-900 to-emerald-950 border border-amber-400/50 w-full max-w-md rounded-2xl shadow-2xl p-5 sm:p-6 text-white space-y-5 relative overflow-hidden">
        {/* Subtle decorative glow */}
        <div className="absolute -top-16 -left-16 w-36 h-36 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -right-16 w-36 h-36 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Victory Header */}
        <div className="text-center space-y-2 pt-2">
          <div className="inline-flex p-3 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-emerald-950 shadow-lg shadow-amber-950/60 animate-bounce">
            <Trophy className="w-8 h-8" />
          </div>

          <div className="space-y-0.5">
            <span className="text-xs font-bold text-amber-400 tracking-wider uppercase">
              {t.winnerTrophy}
            </span>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              {winner === 'tie' ? t.tied : `${winnerName} ${t.winnerBanner}`}
            </h2>
            {winner !== 'tie' && (
              <p className="text-xs text-emerald-300">
                {t.leadBy} {formatNumber(scoreDiff, lang, useBengaliDigits)} {lang === 'bn' ? 'পয়েন্ট' : 'points'}
              </p>
            )}
          </div>
        </div>

        {/* Final Scoreboard Comparison */}
        <div className="grid grid-cols-2 gap-3 bg-emerald-950/80 p-3.5 rounded-xl border border-emerald-800/80">
          {/* Team 1 Final */}
          <div
            className={`p-3 rounded-lg border text-center ${
              winner === 1
                ? 'bg-rose-950/60 border-amber-400/80 ring-1 ring-amber-400/50'
                : 'bg-emerald-900/40 border-emerald-800/60 opacity-80'
            }`}
          >
            <div className="text-xs font-bold text-rose-300 truncate">
              {team1Name}
            </div>
            <div className="text-3xl font-black font-mono text-white my-1">
              {formatNumber(team1Score, lang, useBengaliDigits)}
            </div>
            <div className="text-[10px] text-emerald-300/80 flex items-center justify-center gap-1">
              <Shield className="w-3 h-3 text-rose-400" />
              <span>{playerNames.p1} & {playerNames.p3}</span>
            </div>
          </div>

          {/* Team 2 Final */}
          <div
            className={`p-3 rounded-lg border text-center ${
              winner === 2
                ? 'bg-blue-950/60 border-amber-400/80 ring-1 ring-amber-400/50'
                : 'bg-emerald-900/40 border-emerald-800/60 opacity-80'
            }`}
          >
            <div className="text-xs font-bold text-blue-300 truncate">
              {team2Name}
            </div>
            <div className="text-3xl font-black font-mono text-white my-1">
              {formatNumber(team2Score, lang, useBengaliDigits)}
            </div>
            <div className="text-[10px] text-emerald-300/80 flex items-center justify-center gap-1">
              <Award className="w-3 h-3 text-blue-400" />
              <span>{playerNames.p2} & {playerNames.p4}</span>
            </div>
          </div>
        </div>

        {/* Match Statistics */}
        <div className="bg-emerald-900/40 rounded-xl p-3 border border-emerald-800/60 text-xs flex justify-around text-center">
          <div>
            <div className="text-emerald-400/80 text-[11px]">{t.totalRoundsPlayed}</div>
            <div className="text-base font-bold font-mono text-white">
              {formatNumber(rounds.length, lang, useBengaliDigits)}
            </div>
          </div>
          <div className="w-px bg-emerald-800" />
          <div>
            <div className="text-emerald-400/80 text-[11px]">{t.matchedOn}</div>
            <div className="text-xs font-semibold text-white">
              {new Date().toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </div>
          </div>
        </div>

        {/* Share Button */}
        <div>
          <button
            onClick={handleShare}
            className="w-full py-2.5 px-3 rounded-xl bg-emerald-800/80 hover:bg-emerald-700/80 border border-emerald-600/60 text-xs font-semibold text-emerald-100 flex items-center justify-center gap-2 transition"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-amber-400" />
                <span className="text-amber-300">{t.shareCopied}</span>
              </>
            ) : (
              <>
                <Share2 className="w-4 h-4 text-emerald-300" />
                <span>{t.shareMatch}</span>
              </>
            )}
          </button>
        </div>

        {/* Primary Action Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-emerald-800/60">
          <button
            onClick={onSaveAndReset}
            className="py-3 px-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-emerald-950 font-black text-xs sm:text-sm shadow-md flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{t.startAnotherGame}</span>
          </button>

          <button
            onClick={onOpenHistory}
            className="py-3 px-3 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm border border-emerald-600/70 shadow-md flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            <History className="w-4 h-4 text-amber-300" />
            <span>{t.history}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
