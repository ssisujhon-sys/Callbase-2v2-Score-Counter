/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Edit3, Plus, Minus, Save, X, RotateCcw } from 'lucide-react';
import { GameSettings, Language, Round, RoundPlayerCall } from '../types';
import { formatNumber, translations } from '../i18n';
import { soundEngine } from '../hooks/useSound';

interface EditRoundModalProps {
  isOpen: boolean;
  onClose: () => void;
  round: Round | null;
  settings: GameSettings;
  lang: Language;
  onSaveEdit: (roundNumber: number, newCalls: RoundPlayerCall) => void;
}

export const EditRoundModal: React.FC<EditRoundModalProps> = ({
  isOpen,
  onClose,
  round,
  settings,
  lang,
  onSaveEdit,
}) => {
  const t = translations[lang];
  const { team1Name, team2Name, playerNames, useBengaliDigits, soundEnabled } = settings;

  const [calls, setCalls] = useState<RoundPlayerCall>(() => ({
    p1: round?.calls.p1 || 0,
    p2: round?.calls.p2 || 0,
    p3: round?.calls.p3 || 0,
    p4: round?.calls.p4 || 0,
  }));

  // Re-sync whenever opened
  React.useEffect(() => {
    if (round) {
      setCalls({ ...round.calls });
    }
  }, [round]);

  if (!isOpen || !round) return null;

  const team1Round = (calls.p1 || 0) + (calls.p3 || 0);
  const team2Round = (calls.p2 || 0) + (calls.p4 || 0);

  const handleCallSelect = (player: 'p1' | 'p2' | 'p3' | 'p4', val: number) => {
    if (soundEnabled) soundEngine.playChip();
    setCalls((prev) => ({ ...prev, [player]: Math.max(0, val) }));
  };

  const handleStepCall = (player: 'p1' | 'p2' | 'p3' | 'p4', delta: number) => {
    if (soundEnabled) soundEngine.playChip();
    setCalls((prev) => ({
      ...prev,
      [player]: Math.max(0, (prev[player] || 0) + delta),
    }));
  };

  const handleResetCall = (player: 'p1' | 'p2' | 'p3' | 'p4') => {
    if (soundEnabled) soundEngine.playChip();
    setCalls((prev) => ({ ...prev, [player]: 0 }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (soundEnabled) soundEngine.playSuccess();
    onSaveEdit(round.roundNumber, calls);
    onClose();
  };

  const quickCallPresets = [0, 50, 100, 150, 200];

  const renderPlayerEditRow = (
    player: 'p1' | 'p2' | 'p3' | 'p4',
    teamColor: 'rose' | 'blue'
  ) => {
    return (
      <div className="bg-emerald-950/80 p-3 rounded-xl border border-emerald-800/80 space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className={`font-bold ${teamColor === 'rose' ? 'text-rose-300' : 'text-blue-300'}`}>
            {playerNames[player]}
          </span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => handleResetCall(player)}
              className="text-[10px] text-emerald-300 hover:text-white px-1.5 py-0.5 rounded bg-emerald-900 border border-emerald-700/60"
            >
              Reset
            </button>
            <span className="font-mono font-black text-amber-300 bg-emerald-900 px-2 py-0.5 rounded border border-emerald-700 min-w-10 text-center">
              {formatNumber(calls[player], lang, useBengaliDigits)}
            </span>
          </div>
        </div>

        {/* 50, 100, 150, 200 buttons */}
        <div className="flex items-center gap-1">
          {quickCallPresets.map((val) => (
            <button
              key={val}
              type="button"
              onClick={() => handleCallSelect(player, val)}
              className={`flex-1 py-1 rounded text-xs font-bold transition ${
                calls[player] === val
                  ? 'bg-amber-400 text-emerald-950 ring-2 ring-amber-300'
                  : 'bg-emerald-900/60 text-emerald-200 hover:bg-emerald-800 border border-emerald-700/50'
              }`}
            >
              {val === 0 ? t.pass : formatNumber(val, lang, useBengaliDigits)}
            </button>
          ))}
        </div>

        {/* Fine-tune stepper */}
        <div className="flex items-center justify-end gap-1 text-[11px] pt-1 border-t border-emerald-900/60">
          <button
            type="button"
            onClick={() => handleStepCall(player, -50)}
            className="px-2 py-0.5 rounded bg-emerald-900 hover:bg-emerald-800 text-emerald-200 border border-emerald-700/60 font-mono"
          >
            -50
          </button>
          <button
            type="button"
            onClick={() => handleStepCall(player, -10)}
            className="px-1.5 py-0.5 rounded bg-emerald-900 hover:bg-emerald-800 text-emerald-200 border border-emerald-700/60 font-mono"
          >
            -10
          </button>
          <button
            type="button"
            onClick={() => handleStepCall(player, 10)}
            className="px-1.5 py-0.5 rounded bg-emerald-900 hover:bg-emerald-800 text-emerald-200 border border-emerald-700/60 font-mono"
          >
            +10
          </button>
          <button
            type="button"
            onClick={() => handleStepCall(player, 50)}
            className="px-2 py-0.5 rounded bg-emerald-900 hover:bg-emerald-800 text-emerald-200 border border-emerald-700/60 font-mono"
          >
            +50
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-emerald-950 border border-emerald-700/80 w-full max-w-lg rounded-2xl shadow-2xl p-5 text-white space-y-4 relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5">
          <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400">
            <Edit3 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white">
              {t.editRoundTitle} - {t.round} {formatNumber(round.roundNumber, lang, useBengaliDigits)}
            </h2>
            <p className="text-[11px] text-emerald-300/80">
              {lang === 'bn' ? 'যেকোনো খেলোয়াড়ের কল পরিবর্তন করে সেভ করুন' : 'Change any player call and save'}
            </p>
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          <div className="space-y-3">
            {/* Team 1 Players */}
            <div className="bg-rose-950/20 p-3 rounded-xl border border-rose-900/40 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-rose-300">
                <span>{team1Name}</span>
                <span className="font-mono bg-rose-900/60 px-2 py-0.5 rounded text-rose-200">
                  +{formatNumber(team1Round, lang, useBengaliDigits)} pts
                </span>
              </div>
              {renderPlayerEditRow('p1', 'rose')}
              {renderPlayerEditRow('p3', 'rose')}
            </div>

            {/* Team 2 Players */}
            <div className="bg-blue-950/20 p-3 rounded-xl border border-blue-900/40 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-blue-300">
                <span>{team2Name}</span>
                <span className="font-mono bg-blue-900/60 px-2 py-0.5 rounded text-blue-200">
                  +{formatNumber(team2Round, lang, useBengaliDigits)} pts
                </span>
              </div>
              {renderPlayerEditRow('p2', 'blue')}
              {renderPlayerEditRow('p4', 'blue')}
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-emerald-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-emerald-900 hover:bg-emerald-800 text-xs text-white"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-emerald-950 font-bold text-xs flex items-center gap-1.5 shadow"
            >
              <Save className="w-4 h-4" />
              <span>{t.saveChanges}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
