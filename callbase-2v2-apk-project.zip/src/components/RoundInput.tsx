/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Plus, Minus, RotateCcw, Sparkles } from 'lucide-react';
import { GameSettings, Language, Round, RoundPlayerCall } from '../types';
import { formatNumber, translations } from '../i18n';
import { soundEngine } from '../hooks/useSound';

interface RoundInputProps {
  roundNumber: number;
  settings: GameSettings;
  currentDealer: 'p1' | 'p2' | 'p3' | 'p4';
  team1Score: number;
  team2Score: number;
  lang: Language;
  onRecordRound: (round: Round) => void;
}

export const RoundInput: React.FC<RoundInputProps> = ({
  roundNumber,
  settings,
  currentDealer,
  team1Score,
  team2Score,
  lang,
  onRecordRound,
}) => {
  const t = translations[lang];
  const { team1Name, team2Name, playerNames, useBengaliDigits, soundEnabled } = settings;

  // Current calls for the 4 players
  const [calls, setCalls] = useState<RoundPlayerCall>({
    p1: 50,
    p2: 50,
    p3: 50,
    p4: 50,
  });

  // History for undoing changes on individual players
  const [prevCalls, setPrevCalls] = useState<Partial<Record<'p1' | 'p2' | 'p3' | 'p4', number>>>({});

  // Team round totals
  const team1Round = (calls.p1 || 0) + (calls.p3 || 0);
  const team2Round = (calls.p2 || 0) + (calls.p4 || 0);

  const nextTeam1Total = team1Score + team1Round;
  const nextTeam2Total = team2Score + team2Round;

  const handleCallSelect = (player: 'p1' | 'p2' | 'p3' | 'p4', val: number) => {
    if (soundEnabled) soundEngine.playChip();
    setPrevCalls((prev) => ({ ...prev, [player]: calls[player] }));
    setCalls((prev) => ({ ...prev, [player]: Math.max(0, val) }));
  };

  const handleStepCall = (player: 'p1' | 'p2' | 'p3' | 'p4', delta: number) => {
    if (soundEnabled) soundEngine.playChip();
    setPrevCalls((prev) => ({ ...prev, [player]: calls[player] }));
    setCalls((prev) => ({
      ...prev,
      [player]: Math.max(0, (prev[player] || 0) + delta),
    }));
  };

  const handleUndoPlayerCall = (player: 'p1' | 'p2' | 'p3' | 'p4') => {
    if (soundEnabled) soundEngine.playChip();
    if (prevCalls[player] !== undefined) {
      const restored = prevCalls[player]!;
      setPrevCalls((prev) => {
        const copy = { ...prev };
        delete copy[player];
        return copy;
      });
      setCalls((prev) => ({ ...prev, [player]: restored }));
    } else {
      setCalls((prev) => ({ ...prev, [player]: 0 }));
    }
  };

  const handleResetAll = () => {
    if (soundEnabled) soundEngine.playChip();
    setCalls({ p1: 0, p2: 0, p3: 0, p4: 0 });
    setPrevCalls({});
  };

  const handleSubmitRound = (e: React.FormEvent) => {
    e.preventDefault();
    if (soundEnabled) soundEngine.playSuccess();

    const newRound: Round = {
      roundNumber,
      calls: { ...calls },
      team1Call: team1Round,
      team2Call: team2Round,
      team1TotalScore: nextTeam1Total,
      team2TotalScore: nextTeam2Total,
      dealerPlayerId: currentDealer,
      timestamp: Date.now(),
    };

    onRecordRound(newRound);

    // Reset default calls for next round
    setCalls({ p1: 50, p2: 50, p3: 50, p4: 50 });
    setPrevCalls({});
  };

  const quickCallPresets = [0, 50, 100, 150, 200];

  const renderCompactPlayerCard = (
    player: 'p1' | 'p2' | 'p3' | 'p4',
    teamColor: 'rose' | 'blue'
  ) => {
    const isDealer = currentDealer === player;
    const canUndo = prevCalls[player] !== undefined;

    return (
      <div
        className={`bg-emerald-950/90 border ${
          teamColor === 'rose' ? 'border-rose-900/60' : 'border-blue-900/60'
        } rounded-xl p-2 sm:p-2.5 shadow-sm space-y-1.5`}
      >
        {/* Row 1: Player Name, Dealer badge, Undo, Call Value */}
        <div className="flex items-center justify-between gap-1 text-xs">
          <div className="flex items-center gap-1 min-w-0">
            <span
              className={`font-bold truncate text-[11px] sm:text-xs ${
                teamColor === 'rose' ? 'text-rose-300' : 'text-blue-300'
              }`}
            >
              {playerNames[player]}
            </span>
            {isDealer && (
              <span className="text-[9px] bg-amber-400 text-black px-1 rounded font-black shrink-0">
                D
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 shrink-0">
            {/* Undo button */}
            <button
              type="button"
              onClick={() => handleUndoPlayerCall(player)}
              className="text-[10px] text-emerald-400 hover:text-amber-300 p-1 rounded bg-emerald-900/80 hover:bg-emerald-800 transition"
              title={t.undoCall}
            >
              <RotateCcw className="w-3 h-3" />
            </button>

            {/* Current Call Display */}
            <span className="font-mono font-black text-amber-300 text-xs sm:text-sm bg-emerald-900 px-2 py-0.5 rounded border border-emerald-700/80 min-w-8 text-center leading-tight">
              {formatNumber(calls[player], lang, useBengaliDigits)}
            </span>
          </div>
        </div>

        {/* Row 2: Tactile One-Touch Buttons: 0, 50, 100, 150, 200 */}
        <div className="grid grid-cols-5 gap-1">
          {quickCallPresets.map((val) => {
            const isSelected = calls[player] === val;
            return (
              <button
                key={val}
                type="button"
                onClick={() => handleCallSelect(player, val)}
                className={`py-1.5 rounded-lg text-xs font-bold transition transform active:scale-95 cursor-pointer text-center ${
                  isSelected
                    ? 'bg-amber-400 text-emerald-950 font-black shadow-md ring-1 ring-amber-300'
                    : 'bg-emerald-900/70 text-emerald-100 hover:bg-emerald-850 border border-emerald-700/50'
                }`}
              >
                {val === 0 ? t.pass : formatNumber(val, lang, useBengaliDigits)}
              </button>
            );
          })}
        </div>

        {/* Mini Stepper for fine-tuning */}
        <div className="flex items-center justify-between text-[10px] text-emerald-400/80 pt-0.5">
          <span>{t.editCall}:</span>
          <div className="flex items-center gap-1 font-mono font-bold">
            <button
              type="button"
              onClick={() => handleStepCall(player, -50)}
              className="px-1.5 py-0.5 rounded bg-emerald-900 hover:bg-emerald-800 text-emerald-200 border border-emerald-700/60"
            >
              -50
            </button>
            <button
              type="button"
              onClick={() => handleStepCall(player, 10)}
              className="px-1.5 py-0.5 rounded bg-emerald-900 hover:bg-emerald-800 text-emerald-200 border border-emerald-700/60"
            >
              +10
            </button>
            <button
              type="button"
              onClick={() => handleStepCall(player, 50)}
              className="px-1.5 py-0.5 rounded bg-emerald-900 hover:bg-emerald-800 text-emerald-200 border border-emerald-700/60"
            >
              +50
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-emerald-900/60 border border-emerald-700/60 rounded-xl p-2.5 sm:p-4 shadow-md space-y-2.5">
      {/* Title bar with quick reset */}
      <div className="flex items-center justify-between pb-1.5 border-b border-emerald-800/80 text-xs">
        <div className="flex items-center gap-1.5">
          <span className="text-amber-400 font-bold text-sm">♠</span>
          <h3 className="font-extrabold text-white text-xs sm:text-sm">
            {t.calls} (50, 100, 150, 200)
          </h3>
        </div>

        <div className="flex items-center gap-2">
          {/* Round Subtotals preview */}
          <div className="text-[11px] font-mono">
            <span className="text-rose-300 font-bold">
              +{formatNumber(team1Round, lang, useBengaliDigits)}
            </span>
            <span className="text-emerald-500 mx-1">/</span>
            <span className="text-blue-300 font-bold">
              +{formatNumber(team2Round, lang, useBengaliDigits)}
            </span>
          </div>

          <button
            type="button"
            onClick={handleResetAll}
            className="text-[10px] text-emerald-300 hover:text-white bg-emerald-950 px-2 py-0.5 rounded border border-emerald-700/60 flex items-center gap-1"
            title="Reset calls"
          >
            <RotateCcw className="w-2.5 h-2.5" />
            <span>0</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmitRound} className="space-y-2.5">
        {/* 4 Player Call Cards in 2 Columns (Zero scroll layout) */}
        <div className="grid grid-cols-2 gap-2 sm:gap-3">
          {/* Column 1: Team 1 (Player 1 & Player 3) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between px-1 text-[11px] font-bold text-rose-300">
              <span className="truncate">{team1Name}</span>
              <span className="font-mono bg-rose-950/80 px-1.5 py-0.2 rounded text-[10px] border border-rose-900/60">
                +{formatNumber(team1Round, lang, useBengaliDigits)}
              </span>
            </div>
            {renderCompactPlayerCard('p1', 'rose')}
            {renderCompactPlayerCard('p3', 'rose')}
          </div>

          {/* Column 2: Team 2 (Player 2 & Player 4) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between px-1 text-[11px] font-bold text-blue-300">
              <span className="truncate">{team2Name}</span>
              <span className="font-mono bg-blue-950/80 px-1.5 py-0.2 rounded text-[10px] border border-blue-900/60">
                +{formatNumber(team2Round, lang, useBengaliDigits)}
              </span>
            </div>
            {renderCompactPlayerCard('p2', 'blue')}
            {renderCompactPlayerCard('p4', 'blue')}
          </div>
        </div>

        {/* Action Button: Save Round immediately under thumb reach */}
        <div>
          <button
            type="submit"
            className="w-full py-3 px-4 rounded-xl font-black text-sm sm:text-base bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-emerald-950 shadow-md shadow-amber-950/40 flex items-center justify-center gap-2 transition transform active:scale-98 border border-amber-300/80 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 fill-emerald-950" />
            <span>{t.addRoundScore}</span>
            <span className="text-xs bg-emerald-950/20 px-2 py-0.5 rounded font-mono font-bold">
              +{formatNumber(team1Round, lang, useBengaliDigits)} / +{formatNumber(team2Round, lang, useBengaliDigits)}
            </span>
          </button>
        </div>
      </form>
    </div>
  );
};
