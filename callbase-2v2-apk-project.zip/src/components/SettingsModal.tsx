/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Settings, Save, X, Users, Shield, Award } from 'lucide-react';
import { GameSettings, Language } from '../types';
import { translations } from '../i18n';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GameSettings;
  lang: Language;
  onSaveSettings: (newSettings: GameSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  lang,
  onSaveSettings,
}) => {
  const [formData, setFormData] = useState<GameSettings>({ ...settings });
  const t = translations[lang];

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-emerald-950 border border-emerald-700/80 w-full max-w-lg rounded-2xl shadow-2xl p-5 sm:p-6 text-white space-y-5 relative max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">
              {t.settings}
            </h2>
            <p className="text-xs text-emerald-300/80">
              {lang === 'bn' ? 'দল ও খেলোয়াড়দের নাম পরিবর্তন করুন' : 'Customize team & player names and preferences'}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Section 1: Team & Player Names */}
          <div className="bg-emerald-900/40 p-3.5 rounded-xl border border-emerald-800/60 space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300 uppercase tracking-wider">
              <Users className="w-3.5 h-3.5" />
              <span>{t.editPlayerNames}</span>
            </div>

            {/* Team 1 & Players */}
            <div className="space-y-2 bg-rose-950/30 p-2.5 rounded-lg border border-rose-900/40">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-rose-400 shrink-0" />
                <input
                  type="text"
                  value={formData.team1Name}
                  onChange={(e) => setFormData({ ...formData, team1Name: e.target.value })}
                  placeholder={t.team1}
                  className="w-full text-xs font-bold bg-emerald-950/80 text-rose-200 border border-rose-800/60 rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-rose-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-[10px] text-emerald-300/80 block mb-0.5">Player 1 (Team 1)</label>
                  <input
                    type="text"
                    value={formData.playerNames.p1}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        playerNames: { ...formData.playerNames, p1: e.target.value },
                      })
                    }
                    className="w-full bg-emerald-950 text-white text-xs border border-emerald-800 rounded px-2 py-1"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-emerald-300/80 block mb-0.5">Player 3 (Team 1)</label>
                  <input
                    type="text"
                    value={formData.playerNames.p3}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        playerNames: { ...formData.playerNames, p3: e.target.value },
                      })
                    }
                    className="w-full bg-emerald-950 text-white text-xs border border-emerald-800 rounded px-2 py-1"
                  />
                </div>
              </div>
            </div>

            {/* Team 2 & Players */}
            <div className="space-y-2 bg-blue-950/30 p-2.5 rounded-lg border border-blue-900/40">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-blue-400 shrink-0" />
                <input
                  type="text"
                  value={formData.team2Name}
                  onChange={(e) => setFormData({ ...formData, team2Name: e.target.value })}
                  placeholder={t.team2}
                  className="w-full text-xs font-bold bg-emerald-950/80 text-blue-200 border border-blue-800/60 rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-[10px] text-emerald-300/80 block mb-0.5">Player 2 (Team 2)</label>
                  <input
                    type="text"
                    value={formData.playerNames.p2}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        playerNames: { ...formData.playerNames, p2: e.target.value },
                      })
                    }
                    className="w-full bg-emerald-950 text-white text-xs border border-emerald-800 rounded px-2 py-1"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-emerald-300/80 block mb-0.5">Player 4 (Team 2)</label>
                  <input
                    type="text"
                    value={formData.playerNames.p4}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        playerNames: { ...formData.playerNames, p4: e.target.value },
                      })
                    }
                    className="w-full bg-emerald-950 text-white text-xs border border-emerald-800 rounded px-2 py-1"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Preferences */}
          <div className="bg-emerald-900/40 p-3.5 rounded-xl border border-emerald-800/60 space-y-3 text-xs">
            {/* Target Score (optional) */}
            <div>
              <label className="font-bold text-emerald-200 block mb-1">
                {t.targetScore}
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="0"
                  step="50"
                  value={formData.targetScore}
                  onChange={(e) =>
                    setFormData({ ...formData, targetScore: parseInt(e.target.value, 10) || 0 })
                  }
                  className="w-32 bg-emerald-950 font-mono text-center font-bold text-sm text-white border border-emerald-800 rounded px-2 py-1.5"
                />
                <span className="text-[11px] text-emerald-400/80">
                  {t.targetScoreHint}
                </span>
              </div>
            </div>

            {/* Bengali Numbers Checkbox */}
            {lang === 'bn' && (
              <label className="flex items-center gap-2.5 cursor-pointer pt-1 border-t border-emerald-800/60">
                <input
                  type="checkbox"
                  checked={formData.useBengaliDigits}
                  onChange={(e) => setFormData({ ...formData, useBengaliDigits: e.target.checked })}
                  className="w-4 h-4 accent-amber-400 rounded cursor-pointer"
                />
                <span className="text-emerald-200 font-medium">
                  {t.useBengaliDigits}
                </span>
              </label>
            )}

            {/* Sound Checkbox */}
            <label className="flex items-center gap-2.5 cursor-pointer pt-1 border-t border-emerald-800/60">
              <input
                type="checkbox"
                checked={formData.soundEnabled}
                onChange={(e) => setFormData({ ...formData, soundEnabled: e.target.checked })}
                className="w-4 h-4 accent-amber-400 rounded cursor-pointer"
              />
              <span className="text-emerald-200 font-medium">
                {t.soundEffects}
              </span>
            </label>
          </div>

          {/* Submit Action */}
          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-emerald-900 hover:bg-emerald-800 text-xs text-white"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-emerald-950 font-bold text-xs flex items-center gap-1.5 shadow cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{lang === 'bn' ? 'সংরক্ষণ করুন' : 'Save Settings'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
