/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FinishedGame, GameSettings, Language, Round } from '../types';

const SETTINGS_KEY = 'callbase_settings_v2';
const HISTORY_KEY = 'callbase_history_v2';
const ACTIVE_GAME_KEY = 'callbase_active_match_v2';
const LANG_KEY = 'callbase_lang_v2';

export const defaultSettings: GameSettings = {
  team1Name: 'Team 1',
  team2Name: 'Team 2',
  playerNames: {
    p1: 'Player 1',
    p2: 'Player 2',
    p3: 'Player 3',
    p4: 'Player 4',
  },
  targetScore: 0,
  useBengaliDigits: true,
  soundEnabled: true,
};

export function loadStoredLanguage(): Language {
  try {
    const saved = localStorage.getItem(LANG_KEY);
    if (saved === 'en' || saved === 'bn') return saved;
  } catch {
    // fallback
  }
  return 'bn';
}

export function saveStoredLanguage(lang: Language): void {
  try {
    localStorage.setItem(LANG_KEY, lang);
  } catch {
    // ignore
  }
}

export function loadStoredSettings(): GameSettings {
  try {
    const data = localStorage.getItem(SETTINGS_KEY);
    if (data) {
      return { ...defaultSettings, ...JSON.parse(data) };
    }
  } catch {
    // fallback
  }
  return defaultSettings;
}

export function saveStoredSettings(settings: GameSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // ignore
  }
}

export function loadStoredHistory(): FinishedGame[] {
  try {
    const data = localStorage.getItem(HISTORY_KEY);
    if (data) {
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return parsed.sort((a, b) => b.timestamp - a.timestamp);
      }
    }
  } catch (err) {
    console.error('Failed to load history:', err);
  }
  return [];
}

export function saveGameToHistory(game: FinishedGame): FinishedGame[] {
  try {
    const current = loadStoredHistory();
    const updated = [game, ...current.filter((g) => g.id !== game.id)];
    localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
    return updated;
  } catch (err) {
    console.error('Failed to save to history:', err);
    return [];
  }
}

export function deleteGameFromHistory(id: string): FinishedGame[] {
  try {
    const current = loadStoredHistory();
    const updated = current.filter((g) => g.id !== id);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
    return updated;
  } catch (err) {
    console.error('Failed to delete history item:', err);
    return [];
  }
}

export function clearAllHistory(): void {
  try {
    localStorage.removeItem(HISTORY_KEY);
  } catch {
    // ignore
  }
}

export interface ActiveGameState {
  settings: GameSettings;
  rounds: Round[];
  currentDealer: 'p1' | 'p2' | 'p3' | 'p4';
}

export function loadActiveGame(): ActiveGameState | null {
  try {
    const data = localStorage.getItem(ACTIVE_GAME_KEY);
    if (data) {
      return JSON.parse(data);
    }
  } catch {
    // ignore
  }
  return null;
}

export function saveActiveGame(state: ActiveGameState): void {
  try {
    localStorage.setItem(ACTIVE_GAME_KEY, JSON.stringify(state));
  } catch {
    // ignore
  }
}

export function clearActiveGame(): void {
  try {
    localStorage.removeItem(ACTIVE_GAME_KEY);
  } catch {
    // ignore
  }
}
