/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ScoreBoard } from './components/ScoreBoard';
import { RoundInput } from './components/RoundInput';
import { RoundHistoryTable } from './components/RoundHistoryTable';
import { StartGameModal } from './components/StartGameModal';
import { EditRoundModal } from './components/EditRoundModal';
import { FinishGameModal } from './components/FinishGameModal';
import { HistoryModal } from './components/HistoryModal';
import { SettingsModal } from './components/SettingsModal';
import { RulesModal } from './components/RulesModal';
import { AndroidInstallModal } from './components/AndroidInstallModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { FinishedGame, GameSettings, Language, Round, RoundPlayerCall } from './types';
import {
  clearActiveGame,
  clearAllHistory,
  deleteGameFromHistory,
  loadActiveGame,
  loadStoredHistory,
  loadStoredLanguage,
  loadStoredSettings,
  saveActiveGame,
  saveGameToHistory,
  saveStoredLanguage,
  saveStoredSettings,
} from './utils/storage';
import { soundEngine } from './hooks/useSound';
import { translations } from './i18n';

// Recalculates all round cumulative totals
function recalculateRounds(rawRounds: { calls: RoundPlayerCall; dealerPlayerId: 'p1' | 'p2' | 'p3' | 'p4'; timestamp: number }[]): {
  recalculated: Round[];
  t1Total: number;
  t2Total: number;
} {
  let runningT1 = 0;
  let runningT2 = 0;

  const recalculated: Round[] = rawRounds.map((r, index) => {
    const team1Call = (r.calls.p1 || 0) + (r.calls.p3 || 0);
    const team2Call = (r.calls.p2 || 0) + (r.calls.p4 || 0);
    runningT1 += team1Call;
    runningT2 += team2Call;

    return {
      roundNumber: index + 1,
      calls: { ...r.calls },
      team1Call,
      team2Call,
      team1TotalScore: runningT1,
      team2TotalScore: runningT2,
      dealerPlayerId: r.dealerPlayerId,
      timestamp: r.timestamp,
    };
  });

  return { recalculated, t1Total: runningT1, t2Total: runningT2 };
}

export default function App() {
  const [lang, setLang] = useState<Language>(() => loadStoredLanguage());
  const [settings, setSettings] = useState<GameSettings>(() => loadStoredSettings());
  const [history, setHistory] = useState<FinishedGame[]>(() => loadStoredHistory());

  // Active game state
  const [rounds, setRounds] = useState<Round[]>(() => {
    const active = loadActiveGame();
    return active ? active.rounds : [];
  });
  const [currentDealer, setCurrentDealer] = useState<'p1' | 'p2' | 'p3' | 'p4'>(() => {
    const active = loadActiveGame();
    return active ? active.currentDealer : 'p1';
  });

  // Start Game Modal on opening if no rounds are active
  const [isStartGameModalOpen, setIsStartGameModalOpen] = useState<boolean>(() => {
    const active = loadActiveGame();
    return !active || active.rounds.length === 0;
  });

  // Calculate current total scores directly from cumulative rounds
  const team1Score = rounds.length > 0 ? rounds[rounds.length - 1].team1TotalScore : 0;
  const team2Score = rounds.length > 0 ? rounds[rounds.length - 1].team2TotalScore : 0;

  // Other Modals state
  const [editingRound, setEditingRound] = useState<Round | null>(null);
  const [isFinishModalOpen, setIsFinishModalOpen] = useState(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isRulesModalOpen, setIsRulesModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);

  const t = translations[lang];

  // Rotate dealer clockwise: p1 -> p2 -> p3 -> p4 -> p1
  const getNextDealer = (dealer: 'p1' | 'p2' | 'p3' | 'p4'): 'p1' | 'p2' | 'p3' | 'p4' => {
    switch (dealer) {
      case 'p1':
        return 'p2';
      case 'p2':
        return 'p3';
      case 'p3':
        return 'p4';
      case 'p4':
        return 'p1';
    }
  };

  // Autosave active game state
  useEffect(() => {
    saveActiveGame({
      settings,
      rounds,
      currentDealer,
    });
  }, [settings, rounds, currentDealer]);

  // Language Toggle
  const handleToggleLang = () => {
    const nextLang = lang === 'en' ? 'bn' : 'en';
    setLang(nextLang);
    saveStoredLanguage(nextLang);
  };

  // Sound Toggle
  const handleToggleSound = () => {
    const updated = { ...settings, soundEnabled: !settings.soundEnabled };
    setSettings(updated);
    saveStoredSettings(updated);
  };

  // Start new game from StartGameModal
  const handleConfirmStartGame = (updatedSettings: GameSettings) => {
    setSettings(updatedSettings);
    saveStoredSettings(updatedSettings);
    clearActiveGame();
    setRounds([]);
    setCurrentDealer('p1');
    setIsStartGameModalOpen(false);
  };

  // Record a completed round
  const handleRecordRound = (newRound: Round) => {
    const nextRounds = [...rounds, newRound];
    setRounds(nextRounds);
    setCurrentDealer(getNextDealer(currentDealer));

    // Optional: auto-trigger finish if user set target score > 0
    if (
      settings.targetScore > 0 &&
      (newRound.team1TotalScore >= settings.targetScore ||
        newRound.team2TotalScore >= settings.targetScore)
    ) {
      handleOpenFinishGame(nextRounds);
    }
  };

  // Undo / Delete last round
  const handleDeleteLastRound = () => {
    if (rounds.length === 0) return;
    if (!window.confirm(t.undoRoundConfirm)) return;

    if (settings.soundEnabled) soundEngine.playChip();
    const updatedRounds = rounds.slice(0, -1);
    setRounds(updatedRounds);

    if (updatedRounds.length === 0) {
      setCurrentDealer('p1');
    } else {
      const last = updatedRounds[updatedRounds.length - 1];
      setCurrentDealer(getNextDealer(last.dealerPlayerId));
    }
  };

  // Delete a specific round by roundNumber
  const handleDeleteSpecificRound = (roundNumber: number) => {
    if (!window.confirm(lang === 'bn' ? `রাউন্ড ${roundNumber} মুছে ফেলতে চান?` : `Delete Round ${roundNumber}?`)) {
      return;
    }

    if (settings.soundEnabled) soundEngine.playChip();
    const filtered = rounds.filter((r) => r.roundNumber !== roundNumber);
    const { recalculated } = recalculateRounds(filtered);
    setRounds(recalculated);

    if (recalculated.length === 0) {
      setCurrentDealer('p1');
    } else {
      const last = recalculated[recalculated.length - 1];
      setCurrentDealer(getNextDealer(last.dealerPlayerId));
    }
  };

  // Edit calls for a specific round
  const handleSaveEditRound = (roundNumber: number, newCalls: RoundPlayerCall) => {
    const updatedRaw = rounds.map((r) => {
      if (r.roundNumber === roundNumber) {
        return {
          ...r,
          calls: { ...newCalls },
        };
      }
      return r;
    });

    const { recalculated } = recalculateRounds(updatedRaw);
    setRounds(recalculated);
    setEditingRound(null);
  };

  // Open Finish Game
  const handleOpenFinishGame = (currentRounds = rounds) => {
    if (settings.soundEnabled) {
      soundEngine.playFanfare();
    }

    const t1 = currentRounds.length > 0 ? currentRounds[currentRounds.length - 1].team1TotalScore : 0;
    const t2 = currentRounds.length > 0 ? currentRounds[currentRounds.length - 1].team2TotalScore : 0;
    const winner: 1 | 2 | 'tie' = t1 > t2 ? 1 : t2 > t1 ? 2 : 'tie';

    const finished: FinishedGame = {
      id: `callbase_${Date.now()}`,
      date: new Date().toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      timestamp: Date.now(),
      team1Name: settings.team1Name,
      team2Name: settings.team2Name,
      playerNames: { ...settings.playerNames },
      winnerTeam: winner,
      finalScore: {
        team1: t1,
        team2: t2,
      },
      totalRounds: currentRounds.length,
      rounds: [...currentRounds],
    };

    const updatedHistory = saveGameToHistory(finished);
    setHistory(updatedHistory);
    setIsFinishModalOpen(true);
  };

  // Save and reset match for another game
  const handleSaveAndReset = () => {
    setIsFinishModalOpen(false);
    clearActiveGame();
    setRounds([]);
    setCurrentDealer('p1');
    setIsStartGameModalOpen(true);
  };

  // Reset match prompt
  const handleResetGamePrompt = () => {
    setIsStartGameModalOpen(true);
  };

  // History operations
  const handleDeleteHistoryMatch = (id: string) => {
    const updated = deleteGameFromHistory(id);
    setHistory(updated);
  };

  const handleClearAllHistory = () => {
    clearAllHistory();
    setHistory([]);
  };

  const handleSaveSettings = (newSettings: GameSettings) => {
    setSettings(newSettings);
    saveStoredSettings(newSettings);
  };

  const currentRoundNumber = rounds.length + 1;

  return (
    <div className="min-h-screen bg-emerald-950 text-slate-100 flex flex-col font-sans selection:bg-amber-400 selection:text-emerald-950 pb-8">
      {/* Top Application Header */}
      <Header
        lang={lang}
        onToggleLang={handleToggleLang}
        onOpenHistory={() => setIsHistoryModalOpen(true)}
        onOpenSettings={() => setIsSettingsModalOpen(true)}
        onOpenRules={() => setIsRulesModalOpen(true)}
        onOpenInstallGuide={() => setIsInstallModalOpen(true)}
        onResetGame={handleResetGamePrompt}
        historyCount={history.length}
        soundEnabled={settings.soundEnabled}
        onToggleSound={handleToggleSound}
      />

      {/* Main Game Arena - Compact & Mobile Ergonomic */}
      <main className="flex-1 max-w-2xl w-full mx-auto p-2 sm:p-4 space-y-2.5">
        {/* Compact Scoreboard (Total scores & round info without taking up vertical height) */}
        <ScoreBoard
          team1Score={team1Score}
          team2Score={team2Score}
          settings={settings}
          currentRoundNumber={currentRoundNumber}
          currentDealer={currentDealer}
          lang={lang}
          onFinishGame={() => handleOpenFinishGame()}
        />

        {/* Central Round Input: 4 Players Calls in 2-Column Grid (Zero-Scroll layout) */}
        <RoundInput
          roundNumber={currentRoundNumber}
          settings={settings}
          currentDealer={currentDealer}
          team1Score={team1Score}
          team2Score={team2Score}
          lang={lang}
          onRecordRound={handleRecordRound}
        />

        {/* Collapsible Round History Table (Doesn't force page scrolling during play) */}
        <RoundHistoryTable
          rounds={rounds}
          settings={settings}
          lang={lang}
          onDeleteLastRound={handleDeleteLastRound}
          onDeleteSpecificRound={handleDeleteSpecificRound}
          onOpenEditRound={(r) => setEditingRound(r)}
        />
      </main>

      {/* Start Game & Player Names Modal */}
      <StartGameModal
        isOpen={isStartGameModalOpen}
        hasActiveGame={rounds.length > 0}
        activeRoundCount={rounds.length}
        settings={settings}
        lang={lang}
        onToggleLang={handleToggleLang}
        onResumeGame={() => setIsStartGameModalOpen(false)}
        onConfirmStartGame={handleConfirmStartGame}
        onOpenHistory={() => {
          setIsStartGameModalOpen(false);
          setIsHistoryModalOpen(true);
        }}
        onOpenRules={() => {
          setIsStartGameModalOpen(false);
          setIsRulesModalOpen(true);
        }}
      />

      {/* Edit Round Calls Modal */}
      <EditRoundModal
        isOpen={!!editingRound}
        onClose={() => setEditingRound(null)}
        round={editingRound}
        settings={settings}
        lang={lang}
        onSaveEdit={handleSaveEditRound}
      />

      {/* Finish Game Modal */}
      <FinishGameModal
        isOpen={isFinishModalOpen}
        onClose={() => setIsFinishModalOpen(false)}
        team1Score={team1Score}
        team2Score={team2Score}
        rounds={rounds}
        settings={settings}
        lang={lang}
        onSaveAndReset={handleSaveAndReset}
        onOpenHistory={() => {
          setIsFinishModalOpen(false);
          setIsHistoryModalOpen(true);
        }}
      />

      {/* Match History Modal */}
      <HistoryModal
        isOpen={isHistoryModalOpen}
        onClose={() => setIsHistoryModalOpen(false)}
        history={history}
        lang={lang}
        useBengaliDigits={settings.useBengaliDigits}
        onDeleteMatch={handleDeleteHistoryMatch}
        onClearAll={handleClearAllHistory}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={settings}
        lang={lang}
        onSaveSettings={handleSaveSettings}
      />

      {/* Rules Modal */}
      <RulesModal
        isOpen={isRulesModalOpen}
        onClose={() => setIsRulesModalOpen(false)}
        lang={lang}
      />

      {/* Android Install Modal */}
      <AndroidInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        lang={lang}
      />

      {/* Offline Toast Banner */}
      <OfflineIndicator lang={lang} />
    </div>
  );
}
