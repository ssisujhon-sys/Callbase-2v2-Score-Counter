/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Language = 'en' | 'bn';

export interface Player {
  id: 'p1' | 'p2' | 'p3' | 'p4';
  name: string;
  team: 1 | 2;
  position: 'North' | 'East' | 'South' | 'West';
}

export interface RoundPlayerCall {
  p1: number;
  p2: number;
  p3: number;
  p4: number;
}

export interface Round {
  roundNumber: number;
  calls: RoundPlayerCall;
  team1Call: number; // Team 1 score for this round (p1 + p3)
  team2Call: number; // Team 2 score for this round (p2 + p4)
  team1TotalScore: number; // Cumulative Team 1 total
  team2TotalScore: number; // Cumulative Team 2 total
  dealerPlayerId: 'p1' | 'p2' | 'p3' | 'p4';
  timestamp: number;
}

export interface GameSettings {
  team1Name: string;
  team2Name: string;
  playerNames: {
    p1: string; // Team 1
    p2: string; // Team 2
    p3: string; // Team 1
    p4: string; // Team 2
  };
  targetScore: number;
  useBengaliDigits: boolean;
  soundEnabled: boolean;
}

export interface FinishedGame {
  id: string;
  date: string;
  timestamp: number;
  team1Name: string;
  team2Name: string;
  playerNames: {
    p1: string;
    p2: string;
    p3: string;
    p4: string;
  };
  winnerTeam: 1 | 2 | 'tie';
  finalScore: {
    team1: number;
    team2: number;
  };
  totalRounds: number;
  rounds: Round[];
}
